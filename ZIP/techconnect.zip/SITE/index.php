<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>TechConnect</title>
	<link rel="stylesheet" href="style/css/style.css">
	<link rel="shortcut icon" href="style/img/TC.png">
</head>
<body>
	<nav id="nav">
			<a id='h1' href="../index.php">TechConnect</a>
		<div id="flex">
			<b><a href="pages/login.php" class="a">Вход</a></b>
			<b><a href="pages/telegram.php" class="a" >Регистрация / Вход<br> через Telegram</a></b>
		</div>
	</nav>
</body>
</html>	